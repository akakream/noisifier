import unittest

from binary_class_test import binary_class_tests
from multi_class_test import multi_class_tests
from multi_label_test import multi_label_tests

if __name__ == "__main__":

    