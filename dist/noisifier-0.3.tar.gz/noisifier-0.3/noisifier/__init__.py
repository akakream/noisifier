# __init__.py

# Version of noisifier
__version__ = '0.1'

from noisifier.noisifier import Noisifier
