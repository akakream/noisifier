# __init__.py

# Version of noisifier
__version__ = '0.1'

from noisifier.binary_class import Binary_Class_Noisifier
from noisifier.multi_class import Multi_Class_Noisifier
from noisifier.multi_label import Multi_Label_Noisifier
